# node-elk
A quick demo of logging in node.js using [winston](https://github.com/winstonjs/winston) and its [graylog2 extension](https://github.com/namshi/winston-graylog2) to quickly set up some logging in a node app using the ELK stack.
